// Krusieski_Larry March 8 2026 CS-405 SNHU

#include <iostream>
#include <limits>
#include <typeinfo>
#include <cmath>
#include <type_traits>

using namespace std;

template <typename T>
struct NumericResult
{
    bool status;
    T value;
};

template <typename T>
NumericResult<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (is_integral_v<T>)
        {
            if (increment > 0 && result > numeric_limits<T>::max() - increment)
            {
                return { true, result };
            }

            if constexpr (is_signed_v<T>)
            {
                if (increment < 0 && result < numeric_limits<T>::lowest() - increment)
                {
                    return { true, result };
                }
            }
        }
        else if constexpr (is_floating_point_v<T>)
        {
            if (!isfinite(result + increment))
            {
                return { true, result };
            }
        }

        result += increment;
    }

    return { false, result };
}

template <typename T>
NumericResult<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (is_integral_v<T> && is_unsigned_v<T>)
        {
            if (result < decrement)
            {
                return { true, result };
            }
        }
        else if constexpr (is_integral_v<T> && is_signed_v<T>)
        {
            if (decrement > 0 && result < numeric_limits<T>::lowest() + decrement)
            {
                return { true, result };
            }

            if (decrement < 0 && result > numeric_limits<T>::max() + decrement)
            {
                return { true, result };
            }
        }
        else if constexpr (is_floating_point_v<T>)
        {
            if (!isfinite(result - decrement))
            {
                return { true, result };
            }
        }

        result -= decrement;
    }

    return { false, result };
}

template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = numeric_limits<T>::max() / steps;
    const T start = 0;

    cout << "Overflow Test of Type = " << typeid(T).name() << endl;

    cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto result = add_numbers<T>(start, increment, steps);

    if (result.status)
        cout << "*** OVERFLOW DETECTED *** ";

    cout << "overflow status: " << boolalpha << result.status
        << ", result: " << +result.value << endl;

    cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);

    if (result.status)
        cout << "*** OVERFLOW DETECTED *** ";

    cout << "overflow status: " << boolalpha << result.status
        << ", result: " << +result.value << endl;
}

template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = numeric_limits<T>::max() / steps;
    const T start = numeric_limits<T>::max();

    cout << "Underflow Test of Type = " << typeid(T).name() << endl;

    cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);

    if (result.status)
        cout << "*** UNDERFLOW DETECTED *** ";

    cout << "underflow status: " << boolalpha << result.status
        << ", result: " << +result.value << endl;

    cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);

    if (result.status)
        cout << "*** UNDERFLOW DETECTED *** ";

    cout << "underflow status: " << boolalpha << result.status
        << ", result: " << +result.value << endl;
}

void do_overflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Overflow Tests ***" << endl;
    cout << star_line << endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Underflow Tests ***" << endl;
    cout << star_line << endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const string star_line = string(50, '*');

    cout << "Starting Numeric Underflow / Overflow Tests!" << endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    cout << endl << "All Numeric Underflow / Overflow Tests Complete!" << endl;

    return 0;
}